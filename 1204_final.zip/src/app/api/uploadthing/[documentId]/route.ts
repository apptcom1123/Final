import { NextApiRequest, NextApiResponse } from "next";
import formidable from "formidable";
import path from "path";
import fs from "fs/promises";

export const config = {
  api: {
    bodyParser: false,
  },
};

const readFile = async (
  req: NextApiRequest,
  documentId: string
): Promise<{ fields: formidable.Fields; files: formidable.Files }> => {
  const uploadDir = path.join(process.cwd(), `/public/uploads/${documentId}`);

  // Create the upload directory if it doesn't exist
  await fs.mkdir(uploadDir, { recursive: true });

  const options: formidable.Options = {
    uploadDir: uploadDir,
    keepExtensions: true,
    maxFileSize: 4000 * 1024 * 1024, // 4GB (adjust as needed)
    multiples: true,
    filename: (name, ext, part, form) => Date.now().toString() + ext
  };

  const form = formidable(options);
  return new Promise((resolve, reject) => {
    form.parse(req, (err, fields, files) => {
      if (err) reject(err);
      resolve({ fields, files });
    });
  });
};

const handler = async (req: NextApiRequest, res: NextApiResponse) => {
  try {
    // Extract documentId from the URL
    const documentId = req.query.documentId as string;

    // Process the uploaded files
    const { fields, files } = await readFile(req, documentId);

    res.json({ message: "Files uploaded successfully", files });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: "File upload failed" });
  }
};

export default handler;
