"use client";

import FileUploadForm from "./_components/FileUploadForm";
import {useState} from 'react';
import { useDocument } from "@/hooks/useDocument";
import React from "react";
import Image from 'next/image'
import Link from 'next/link'

console.warn = () => {};

function DocPage() {
  const {
    title, setTitle,
    content, setContent,
    createdAt, updatedAt,
    filePath, setFilePath,
    modelParams, setModelParams,
    resultPath, setResultPath,
    status, setStatus
  } = useDocument();
  

  return (
    <div className="w-full">
      <nav className="sticky top-0 flex w-full justify-between p-2 shadow-sm">
        <input
          value={title}
          onChange={(e) => setTitle(e.target.value)}
          placeholder="Document Title"
          className="rounded-lg px-2 py-1 text-slate-700 outline-0 focus:bg-slate-100"
        />
      </nav>

      <nav className="sticky top-0 flex w-full justify-between px-4 p-2 shadow-sm">
        <textarea
          value={content || ""}
          onChange={(e) => setContent(e.target.value)}
          className="h-[10vh] w-full outline-0 "
        />
      </nav>
      
      <nav className="sticky top-0 flex w-full justify-between shadow-sm">
        <section className="w-full px-4 py-4">
          <div className="space-y-2 text-sm text-slate-700">
              <p><strong>Created At:</strong> {createdAt.toDateString()} {createdAt.toTimeString()}</p>
              <p><strong>Updated At:</strong> {updatedAt.toDateString()} {updatedAt.toTimeString()}</p>
          </div>
        </section>
      </nav>
      
      <section className="w-full px-4 py-4">
        <div className="space-y-2 text-sm text-slate-700">
          <p><strong>File Path:</strong> {filePath}</p>
          <p><strong>Model Parameters:</strong> {JSON.stringify(modelParams, null, 2)}</p>
          <p><strong>Result Path:</strong> {resultPath}</p>
          <p><strong>Status:</strong> {status}</p>
        </div>
      </section>
    
    </div>
  );
}

export default DocPage;
