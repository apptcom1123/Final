"use client";

import React, { useState } from "react";
import CustomFileSelector from "./CustomFileSelector";
import ImagePreview from "./ImagePreview";
import { Button } from "@/components/ui/button";

type Props = {
  docId: string;
};

const FileUploadForm = ({ docId }: Props) => {
  const [images, setImages] = useState<File[]>([]);

  const handleFileSelected = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      const _files = Array.from(e.target.files);
      setImages(_files);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    const formData = new FormData();
    images.forEach(image => formData.append('files', image));

    try {
      const response = await fetch(`/api/uploadthing/${docId}`, {
        method: 'POST',
        body: formData,
      });

      if (!response.ok) {
        throw new Error('File upload failed');
      }

      const data = await response.json();
      console.log(data.message);
 
    } catch (error) {
      console.error('Upload error:', error);
    }
  };

  return (
    <form className="w-full" onSubmit={handleSubmit}>
      <div className="flex justify-between">
        <CustomFileSelector
          accept="image/png, image/jpeg"
          onChange={handleFileSelected}
        />
        <Button
          type="submit"
          className="bg-black-50 text-black-500 hover:bg-black-100 py-2 rounded-md"
        >
          Upload
        </Button>
      </div>
      <ImagePreview images={images.slice(0, 3)} />
    </form>
  );
};

export default FileUploadForm;
