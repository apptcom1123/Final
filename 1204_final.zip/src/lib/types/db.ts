export type User = {
  id: string;
  username: string;
  email: string;
  provider: "github" | "credentials";
};

export type Document = {
  id: string;
  title: string;
  content: string;
  createdAt: Date; // Assuming ISO 8601 date format string, adjust as needed
  updatedAt: Date; // Same as above
  filePath: string; // File path (could be a URL or a file system path)
  modelParams: any; // Replace 'any' with a more specific type if known
  resultPath: string; // Path or URL to the result
  status: string; // Status of the document/project
};
