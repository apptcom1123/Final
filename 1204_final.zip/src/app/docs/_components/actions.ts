import { eq } from "drizzle-orm";

import { db } from "@/db";
import { documentsTable, usersToDocumentsTable} from "@/db/schema";

export const createDocument = async (userId: string) => {
  "use server";
  console.log("[createDocument]");

  const defaultFilePath = ""; // Set a default file path or leave empty
  const defaultModelParams = {}; // Set default model parameters or an empty object
  const defaultResultPath = ""; // Set a default result path or leave empty
  const defaultStatus = "new"; // Set an initial status for the document  

  const newDocId = await db.transaction(async (tx) => {
    const [newDoc] = await tx
      .insert(documentsTable)
      .values({
        title: "New Project",
        content: "This is a new project",
        filePath: defaultFilePath,
        modelParams: defaultModelParams,
        resultPath: defaultResultPath,
        status: defaultStatus,
      })
      .returning();
    await tx.insert(usersToDocumentsTable).values({
      userId: userId,
      documentId: newDoc.displayId,
    });
    return newDoc.displayId;
  });
  return newDocId;
};


export const getDocuments = async (userId: string) => {
  "use server";

  const documents = await db.query.usersToDocumentsTable.findMany({
    where: eq(usersToDocumentsTable.userId, userId),
    with: {
      document: {
        columns: {
          displayId: true,
          title: true,
          content: true,
          createdAt: true,
          updatedAt: true,
          filePath: true,
          modelParams: true,
          resultPath: true,
          status: true,
        },
      },
    },
  });
  return documents;
};

export const deleteDocument = async (documentId: string) => {
  "use server";
  console.log("[deleteDocument]");
  await db
    .delete(documentsTable)
    .where(eq(documentsTable.displayId, documentId));
  return;
};

