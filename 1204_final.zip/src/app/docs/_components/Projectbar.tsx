import { AiFillDelete, AiFillFileAdd, AiFillFileText } from "react-icons/ai";
import { RxAvatar } from "react-icons/rx";

import { revalidatePath } from "next/cache";
import Link from "next/link";
import { redirect } from "next/navigation";

import { Button } from "@/components/ui/button";
import { auth } from "@/lib/auth";
import { publicEnv } from "@/lib/env/public";

import { SearchBar } from "@/components/ui/Searchbar";
import { createDocument, deleteDocument, getDocuments } from "./actions";

async function Projectbar() {
  const session = await auth();
  if (!session || !session?.user?.id) {
    redirect(publicEnv.NEXT_PUBLIC_BASE_URL);
  }
  const userId = session.user.id;
  const documents = await getDocuments(userId);

  return (
    <nav className="flex w-full flex-col overflow-y-scroll bg-slate-100 pb-10">
      <nav className="sticky top-0 flex flex-col items-center justify-between border-b bg-slate-100 pb-2">
          <div className="flex w-full items-center justify-between px-3 py-1">
            <div className="flex items-center gap-2">
              <h1 className="text-sm font-semibold">
                Projects
              </h1>
            </div> 
            <form
                className="w-1/2 hover:bg-slate-200"
                action={async () => {
                  "use server";
                  const newDocId = await createDocument(userId);
                  revalidatePath("/docs");
                  redirect(`${publicEnv.NEXT_PUBLIC_BASE_URL}/docs/${newDocId}`);
                }}
              >
                <Button
                  variant={"ghost"}
                  type="submit"
                  className="flex w-full items-center gap-2 px-3 py-1 text-left text-sm text-slate-500"
                >
                  <AiFillFileAdd size={16} />
                  <p>Create Project</p>
                </Button>
              </form>
          </div>        
      </nav>
      <section className="flex w-full flex-col pt-1">
          <SearchBar userId={userId} documents={documents}/>
      </section>    
    </nav>
  );
}

export default Projectbar;
