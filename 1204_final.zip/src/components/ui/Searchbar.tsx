"use client";

import React, { useState } from 'react'
import { Input } from "@/components/ui/input";
import Link from "next/link";

type Documents = {
  document: {
    title: string;  
    displayId: string; 
  };
};

type Props = {
  userId: string;
  documents: Documents[];
};

const SearchBar = ({ userId, documents }: Props) => {
  const [searchInput, setSearchInput] = useState("");

  const filteredDocuments = documents.filter(doc =>
    doc.document.title.toLowerCase().includes(searchInput.toLowerCase())
  );

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setSearchInput(e.target.value);
  };

  // Determine which document array to use based on search input
  const documentsToDisplay = searchInput !== '' ? filteredDocuments : documents;

  return (
    <div className="flex flex-col gap-2 pt-2 px-3">
      <Input
        type={"search"}
        placeholder="Search project here"
        onChange={handleChange}
        value={searchInput}
      />
      <section className="flex w-full flex-col pt-3">
        {documentsToDisplay.map((doc, i) => (
          <div
            key={i}
            className="group flex w-full cursor-pointer items-center justify-between gap-2 text-slate-400 hover:bg-slate-200"
          >
            <Link
              className="grow px-3 py-1"
              href={`/docs/${doc.document.displayId}`}
            >
              <div className="flex items-center gap-2">
                <span className="text-sm font-light">
                  {doc.document.title}
                </span>
              </div>
            </Link>
          </div>
        ))}
      </section>
    </div>
  );
};

export {SearchBar};
