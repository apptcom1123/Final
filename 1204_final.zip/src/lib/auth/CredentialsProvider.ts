import CredentialsProvider from "next-auth/providers/credentials";

import bcrypt from "bcryptjs";
import { eq } from "drizzle-orm";

import { db } from "@/db";
import { usersTable } from "@/db/schema";
import { authSchema } from "@/validators/auth";

export default CredentialsProvider({
  name: "credentials",
  credentials: {
    email: { label: "Email", type: "text" },
    username: { label: "Username", type: "text" },
    password: { label: "Password", type: "password" },
  },
  async authorize(credentials) {    

    let validatedCredentials: {
      email?: string;
      username?: string;
      password: string;
    };

    try {
      validatedCredentials = authSchema.parse(credentials);
    } catch (error) {
      console.log(error)
      console.log("Wrong credentials. Try again.");
      return null;
    }

    const { email, username, password } = validatedCredentials;

    // console.log(email)
    // console.log(username)
    // console.log(password)

    const [ExistedUserByEmail, ExistedUserByUsername] = await Promise.all([
      email
        ? db
        .select({
          id: usersTable.displayId,
          username: usersTable.username,
          email: usersTable.email,
          provider: usersTable.provider,
          hashedPassword: usersTable.hashedPassword,
        })
        .from(usersTable)
        .where(eq(usersTable.email, email.toLowerCase()))
        .execute()        
      : null,
      username
        ? db
            .select({
              id: usersTable.displayId,
              username: usersTable.username,
              email: usersTable.email,
              provider: usersTable.provider,
              hashedPassword: usersTable.hashedPassword,
            })
            .from(usersTable)
            .where(eq(usersTable.username, username))
            .execute()
        : null,
    ]);

    // console.log('Users Table: ', ExistedUserByEmail);
    // console.log('Users Table: ', ExistedUserByUsername);
    

    if ((!ExistedUserByEmail || ExistedUserByEmail.length === 0) && (!ExistedUserByUsername || ExistedUserByUsername.length === 0)) {

      // Sign up
      console.log("Sign up.");
      if (!username) {
        console.log("Name is required.");
        return null;
      }
      const hashedPassword = await bcrypt.hash(password, 10);
      const [createdUser] = await db
        .insert(usersTable)
        .values({
          username,
          email: email!.toLowerCase(),
          hashedPassword,
          provider: "credentials",
        })
        .returning();
      return {
        email: createdUser.email,
        name: createdUser.username,
        id: createdUser.displayId,
      };
    }
  
    if ((ExistedUserByUsername !== null && ExistedUserByUsername !== undefined && ExistedUserByUsername.length === 1)) {
      if (username) { 
          // console.log("username exist")
          const [existedUserByUsername] = await db
          .select({
            id: usersTable.displayId,
            username: usersTable.username,
            email: usersTable.email,
            provider: usersTable.provider,
            hashedPassword: usersTable.hashedPassword,
          })
          .from(usersTable)
          .where(eq(usersTable.username, username))
          .execute();
        
        if (existedUserByUsername) {
          // Sign in with username
          if (existedUserByUsername.provider !== "credentials") {
            console.log(`The username has registered with ${existedUserByUsername.provider}.`);
            return null;
          }
          if (!existedUserByUsername.hashedPassword) {
            console.log("The username has registered with a social account.");
            return null;
          }

          const isValid = await bcrypt.compare(password, existedUserByUsername.hashedPassword);
          if (!isValid) {
            console.log("Wrong password. Try again.");
            return null;
          }

          return {
            email: existedUserByUsername.email,
            name: existedUserByUsername.username,
            id: existedUserByUsername.id,
          };
        }
      }
    }

    if ((ExistedUserByEmail !== null && ExistedUserByEmail !== undefined && ExistedUserByEmail .length === 1)) {
     
      if (email) {

        // console.log("email exist")

        const [existedUserByEmail] = await db
          .select({
            id: usersTable.displayId,
            username: usersTable.username,
            email: usersTable.email,
            provider: usersTable.provider,
            hashedPassword: usersTable.hashedPassword,
          })
          .from(usersTable)
          .where(eq(usersTable.email, email.toLowerCase()))
          .execute();

        if (existedUserByEmail) {
          // Sign in with email
          if (existedUserByEmail.provider !== "credentials") {
            console.log(`The email has registered with ${existedUserByEmail.provider}.`);
            return null;
          }
          if (!existedUserByEmail.hashedPassword) {
            console.log("The email has registered with a social account.");
            return null;
          }

          const isValid = await bcrypt.compare(password, existedUserByEmail.hashedPassword);
          if (!isValid) {
            console.log("Wrong password. Try again.");
            return null;
          }
          return {
            email: existedUserByEmail.email,
            name: existedUserByEmail.username,
            id: existedUserByEmail.id,
          };
        }
      } 
    }
    
    // If no matching user found
    console.log("no one!!")
    return null; // Return null if no user is found
  },
});
