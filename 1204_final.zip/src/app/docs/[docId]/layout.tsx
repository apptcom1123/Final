import ShareDialog from "./_components/ShareDialog";
import FileUploadForm from "./_components/FileUploadForm";

type Props = {
  children: React.ReactNode;
  params: { docId: string };
};

function DocEditorLayout({ children, params }: Props) {
  return (
    <div className="w-full">
      <div className="fixed right-2 top-1 z-50">
        <ShareDialog docId={params.docId} />
      </div>
      {children}
      <main className="flex min-h-screen px-4">
        <FileUploadForm />
      </main>
    </div>
  );
}

export default DocEditorLayout;
