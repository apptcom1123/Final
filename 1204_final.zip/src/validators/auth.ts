import { z } from 'zod';

export const authSchema = z.object({

  username: z.string().optional(),
  email: z.string().optional(),
  password: z.string().min(3),
}).refine((data) => data.username || data.email, {
  message: "Either username or email must be provided",
});
